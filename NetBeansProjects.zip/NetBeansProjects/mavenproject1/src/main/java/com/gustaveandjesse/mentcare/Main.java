
package com.gustaveandjesse.mentcare;

import mentcare.ui.LoginFrame;
import mentcare.ui.PatientUI;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            // Initialize DB (creates file & tables)
            DBHelper.getInstance().init();
            // Show login
            //new LoginFrame().setVisible(true);
            new PatientUI().setVisible(true);
        });
    }
}
