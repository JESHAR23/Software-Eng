package mentcare.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author User
 */
public class PatientUI extends JFrame {
    public PatientUI() {
        setTitle("MentCare - Dashboard");
        setSize(1400,700);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        initUI();
    }

    private void initUI(){
        
        boolean pressed = false;
        
        JPanel left = new JPanel();
        left.setBackground(Color.BLACK);
        left.setLayout(new BorderLayout());
        left.setPreferredSize(new Dimension(450,1));
        
        JPanel pnlN = new JPanel();
        JPanel pnlS = new JPanel();
        JPanel pnlE = new JPanel();
        JPanel pnlW = new JPanel();
        JPanel pnlNC = new JPanel();
        
        JPanel pnlE2 = new JPanel();
        JPanel pnlE3 = new JPanel();
        JPanel pnlEC = new JPanel();
        
        JPanel pnlNC1 = new JPanel();
        JPanel pnlSC1 = new JPanel();
        
        pnlNC.setLayout(new BorderLayout());
        pnlE3.setLayout(new BorderLayout());
        
        pnlEC.setLayout(new BorderLayout());
        
        pnlN.setPreferredSize(new Dimension(1,20));
        pnlS.setPreferredSize(new Dimension(1,20));
        pnlE.setPreferredSize(new Dimension(20,220));
        pnlW.setPreferredSize(new Dimension(20,220));
        
        pnlE2.setPreferredSize(new Dimension(20,220));
        
        JLabel lblchat = new JLabel("Chat Bot");
        lblchat.setVisible(false);
        
        pnlNC1.setPreferredSize(new Dimension(1,40));
        pnlNC1.setLayout(new FlowLayout(FlowLayout.LEFT,0,12));
        pnlNC1.add(lblchat);
        pnlSC1.setPreferredSize(new Dimension(1,20));
                
        JPanel LeftSouth = new JPanel();
        LeftSouth.setLayout(new GridLayout(1,1));
        LeftSouth.setPreferredSize(new Dimension(1,60));
        
        JPanel LeftNorth = new JPanel();
        LeftNorth.setLayout(new GridLayout(2,1,15,8));
        LeftNorth.setPreferredSize(new Dimension(1,70));
        
        JButton btnAppts = new JButton("Appointments");
        btnAppts.setBackground(Color.LIGHT_GRAY);
        btnAppts.setCursor(new Cursor(12));
        
        
        JButton btnback = new JButton("Back");
        btnback.setBackground(Color.LIGHT_GRAY);
        btnback.setCursor(new Cursor(12));
        btnback.setVisible(false);
        
        
        JButton btnLogout = new JButton("Sign In");
        btnLogout.setBackground(Color.LIGHT_GRAY);
        btnLogout.setCursor(new Cursor(12));

        LeftSouth.add(btnLogout);
        LeftNorth.add(btnAppts);
        LeftNorth.add(btnback);
        
        JPanel center = new JPanel(new BorderLayout());
        // start with patient panel
        AppointmentPanel appointmentPanel = new AppointmentPanel();

        ChatbotPanel chatbotPanel = new ChatbotPanel();
        ChatbotPanel chatbotPanel1 = new ChatbotPanel();
        chatbotPanel1.setVisible(false);

        center.add(chatbotPanel, BorderLayout.CENTER);

        btnback.addActionListener(e -> {
            center.removeAll(); center.add(chatbotPanel); center.revalidate(); center.repaint();
            chatbotPanel1.setVisible(false);
            lblchat.setVisible(false);
            btnback.setVisible(false);
        });
        
        btnAppts.addActionListener(e -> {
            center.removeAll(); center.add(appointmentPanel); center.revalidate(); center.repaint();
            chatbotPanel1.setVisible(true);
            lblchat.setVisible(true);
            btnback.setVisible(true);
           
        });

        btnLogout.addActionListener(e -> {
            this.dispose();
            new LoginFrame().setVisible(true);
        });

        pnlEC.add(chatbotPanel1,BorderLayout.CENTER);
        left.add(LeftSouth,BorderLayout.SOUTH);
        left.add(LeftNorth,BorderLayout.NORTH);
        
        
        
        pnlEC.add(pnlNC1,BorderLayout.NORTH);
        pnlEC.add(pnlSC1,BorderLayout.SOUTH); 
        
        left.add(pnlEC,BorderLayout.CENTER);
        
        pnlE3.add(pnlE2,BorderLayout.CENTER);
        pnlE3.add(left,BorderLayout.WEST);
        
        pnlNC.add(pnlE3,BorderLayout.WEST);
        pnlNC.add(center,BorderLayout.CENTER);
        
        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(pnlW, BorderLayout.WEST);
        getContentPane().add(pnlN, BorderLayout.NORTH);
        getContentPane().add(pnlS, BorderLayout.SOUTH);
        getContentPane().add(pnlE, BorderLayout.EAST);
        getContentPane().add(pnlNC, BorderLayout.CENTER);
        
}}
