package mentcare.ui;

import com.gustaveandjesse.mentcare.DBHelper;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class LoginFrame extends JFrame {
    JTextField userField;
    JPasswordField passField;
    JCheckBox chShowPass;
    ImageIcon ImgIcon = new ImageIcon("logo.png");
    public LoginFrame() {
        setTitle("MentCare - Login");
        setSize(360,220);
        setResizable(false);
        setIconImage(ImgIcon.getImage());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        initComponents();
    }
    private void initComponents(){
        JPanel p = new JPanel();
        p.setLayout(null);

        JLabel lblUser = new JLabel("Username:");
        lblUser.setBounds(30,30,80,25);
        p.add(lblUser);

        userField = new JTextField();
        userField.setBounds(120,30,180,25);
        p.add(userField);

        JLabel lblPass = new JLabel("Password:");
        lblPass.setBounds(30,70,80,25);
        p.add(lblPass);

        passField = new JPasswordField();
        passField.setBounds(120,70,180,25);
        passField.setEchoChar('*');
        p.add(passField);

        JButton btnLogin = new JButton("Login");
        btnLogin.setCursor(new Cursor(12));
        btnLogin.setBackground(Color.LIGHT_GRAY);
        btnLogin.setBounds(200,120,100,30);
        p.add(btnLogin);
        
        JButton btnback = new JButton("back");
        btnback.setCursor(new Cursor(12));
        btnback.setBackground(Color.LIGHT_GRAY);
        btnback.setBounds(0,0,80,20);
        p.add(btnback);
        
        chShowPass = new JCheckBox("Show Password");
        chShowPass.setCursor(new Cursor(12));
        chShowPass.setBounds(30,120,150,30);
        p.add(chShowPass);

        btnback.addActionListener(e -> close());
        
        chShowPass.addActionListener(e -> showpass());
        
        btnLogin.addActionListener(e -> doLogin());
        getContentPane().add(p);
    }
        
        public void close(){
            this.dispose();
            new PatientUI().setVisible(true);
        }
        
    public void showpass(){
    
        if (chShowPass.isSelected()){
            passField.setEchoChar((char)0);
        }else passField.setEchoChar('*');
    }

    private void doLogin(){
        String u = userField.getText().trim();
        String p = new String(passField.getPassword()).trim();
        if(u.isEmpty() && p.isEmpty()){
            JOptionPane.showMessageDialog(this, "Enter username and password please.");
            return;
        }else if(u.isEmpty()){
            JOptionPane.showMessageDialog(this, "Enter username please.");
            return;
        }else if(p.isEmpty()){
            JOptionPane.showMessageDialog(this, "Enter password please.");
            return;
        }
        
        try (Connection c = DBHelper.getInstance().getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT name,role FROM staff WHERE username=? AND password=?")){
            ps.setString(1,u); ps.setString(2,p);
            try(ResultSet rs = ps.executeQuery()){
                if(rs.next()){
                    String name = rs.getString("name");
                    String role = rs.getString("role");
                    // open dashboard
                    DashboardFrame dash = new DashboardFrame(name, role);
                    dash.setVisible(true);
                    this.dispose();
                } else {
                    JOptionPane.showMessageDialog(this, "Invalid credentials.");
                }
            }
        } catch (SQLException ex){
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this,"Database error: "+ex.getMessage());
        }
    }
}