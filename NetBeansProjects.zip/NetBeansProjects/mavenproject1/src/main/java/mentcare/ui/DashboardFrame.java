package mentcare.ui;

import javax.swing.*;
import java.awt.*;

public class DashboardFrame extends JFrame {
    private String userName;
    private String role;
    public DashboardFrame(String name, String role) {
        this.userName = name;
        this.role = role;
        setTitle("MentCare - Dashboard (" + userName + " - " + role + ")");
        setSize(1400,700);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        initUI();
    }

    private void initUI(){
        JPanel left = new JPanel();
        left.setBackground(Color.BLACK);
        left.setLayout(new BorderLayout());
        left.setPreferredSize(new Dimension(450,1));
        
        JPanel pnlN = new JPanel();
        JPanel pnlS = new JPanel();
        JPanel pnlE = new JPanel();
        JPanel pnlW = new JPanel();
        JPanel pnlNC = new JPanel();
        
        JPanel pnlE2 = new JPanel();
        JPanel pnlE3 = new JPanel();
        JPanel pnlEC = new JPanel();
        
        JPanel pnlNC1 = new JPanel();
        JPanel pnlSC1 = new JPanel();
        
        pnlNC.setLayout(new BorderLayout());
        pnlE3.setLayout(new BorderLayout());
        
        pnlEC.setLayout(new BorderLayout());
        
        pnlN.setPreferredSize(new Dimension(1,20));
        pnlS.setPreferredSize(new Dimension(1,20));
        pnlE.setPreferredSize(new Dimension(20,220));
        pnlW.setPreferredSize(new Dimension(20,220));
        
        pnlE2.setPreferredSize(new Dimension(20,220));
        
        JLabel lblchat = new JLabel("Chat Bot");
        
        pnlNC1.setPreferredSize(new Dimension(1,40));
        pnlNC1.setLayout(new FlowLayout(FlowLayout.LEFT,0,12));
        pnlNC1.add(lblchat);
        pnlSC1.setPreferredSize(new Dimension(1,20));
                
        JPanel LeftSouth = new JPanel();
        LeftSouth.setBackground(Color.BLACK);
        LeftSouth.setLayout(new GridLayout(1,1));
        LeftSouth.setPreferredSize(new Dimension(1,60));
        
        JPanel LeftNorth = new JPanel();
        LeftNorth.setLayout(new GridLayout(4,1,15,2));
        LeftNorth.setPreferredSize(new Dimension(1,220));
        
        JButton btnPatients = new JButton("Patient Management");
        btnPatients.setBackground(Color.LIGHT_GRAY);
        btnPatients.setCursor(new Cursor(12));
        JButton btnAppts = new JButton("Appointments");
        btnAppts.setBackground(Color.LIGHT_GRAY);
        btnAppts.setCursor(new Cursor(12));
        JButton btnMon = new JButton("Monitoring");
        btnMon.setBackground(Color.LIGHT_GRAY);
        btnMon.setCursor(new Cursor(12));
        JButton btnReports = new JButton("Reports");
        btnReports.setBackground(Color.LIGHT_GRAY);
        btnReports.setCursor(new Cursor(12));
        JButton btnLogout = new JButton("Logout");
        btnLogout.setBackground(Color.LIGHT_GRAY);
        btnLogout.setCursor(new Cursor(12));

        LeftNorth.add(btnPatients); LeftNorth.add(btnAppts); LeftNorth.add(btnMon);
        LeftNorth.add(btnReports); LeftSouth.add(btnLogout);

        JPanel center = new JPanel(new BorderLayout());
        // start with patient panel
        PatientPanel patientPanel = new PatientPanel();
        AppointmentPanel appointmentPanel = new AppointmentPanel();
        MonitoringPanel monitoringPanel = new MonitoringPanel();
        ReportsPanel reportsPanel = new ReportsPanel();
        ChatbotPanel chatbotPanel = new ChatbotPanel();

        center.add(patientPanel, BorderLayout.CENTER);

        btnPatients.addActionListener(e -> {
            center.removeAll(); center.add(patientPanel); center.revalidate(); center.repaint();
        });
        btnAppts.addActionListener(e -> {
            center.removeAll(); center.add(appointmentPanel); center.revalidate(); center.repaint();
        });
        btnMon.addActionListener(e -> {
            center.removeAll(); center.add(monitoringPanel); center.revalidate(); center.repaint();
        });
        btnReports.addActionListener(e -> {
            center.removeAll(); center.add(reportsPanel); center.revalidate(); center.repaint();
        });
        btnLogout.addActionListener(e -> {
            this.dispose();
            new PatientUI().setVisible(true);
        });

        
        left.add(LeftSouth,BorderLayout.SOUTH);
        left.add(LeftNorth,BorderLayout.NORTH);
        
        
        pnlEC.add(chatbotPanel,BorderLayout.CENTER);
        pnlEC.add(pnlNC1,BorderLayout.NORTH);
        pnlEC.add(pnlSC1,BorderLayout.SOUTH); 
        
        left.add(pnlEC,BorderLayout.CENTER);
        
        pnlE3.add(pnlE2,BorderLayout.CENTER);
        pnlE3.add(left,BorderLayout.WEST);
        
        pnlNC.add(pnlE3,BorderLayout.WEST);
        pnlNC.add(center,BorderLayout.CENTER);
        
        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(pnlW, BorderLayout.WEST);
        getContentPane().add(pnlN, BorderLayout.NORTH);
        getContentPane().add(pnlS, BorderLayout.SOUTH);
        getContentPane().add(pnlE, BorderLayout.EAST);
        getContentPane().add(pnlNC, BorderLayout.CENTER);
        
        
    }
}
